import Ckeditor from './ckeditor.vue'

export default Ckeditor