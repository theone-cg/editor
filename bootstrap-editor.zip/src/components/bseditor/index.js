import BootstrapEditor from './ckeditor'

export default BootstrapEditor